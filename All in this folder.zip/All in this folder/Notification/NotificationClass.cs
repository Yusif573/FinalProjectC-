﻿using FinalProjectVacationSite.Person.User;

namespace FinalProjectVacationSite.Notification;

public class NotificationClass
{
    //id,Text,DateTime,FromUser(bu hansi user terefinden bu bildirishin geldiyidir)
    static public int _notificationStaticId {  get; set; }
    public int _notificationId { get; set; }
    public string? Text {  get; set; }
    public DateTime NotificationDate { get; set; }
    public UserClass FromUser { get; set; }
    public string ToUserName {  get; set; }
    public NotificationClass()
    {
        _notificationId = _notificationStaticId++;
        NotificationDate = DateTime.Now;
    }
    public NotificationClass(string text, UserClass user, string toUserName)
        : this()
    {
        Text = text;
        FromUser = user;
        ToUserName = toUserName;
    }
    public string showNotification()
    {
        return $"Id:{_notificationId}\nDate time:{NotificationDate}\n{Text}\nUsername:{FromUser.Username}\nFor:{ToUserName}";
    }
}
