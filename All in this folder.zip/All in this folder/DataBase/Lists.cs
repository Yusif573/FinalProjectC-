﻿using FinalProjectVacationSite.FilesForJob;
using FinalProjectVacationSite.Notification;
using FinalProjectVacationSite.Person.User.Worker;
using System.Text.Json;

namespace FinalProjectVacationSite.DataBase;

public static class Lists
{
    public static List<Admin> admins { get; set; }
    public static List<Vacation> vacations { get; set; }
    public static List<Employer> employers { get; set; }
    public static List<WorkerClass> workers { get; set; }
    public static List<NotificationClass> notifications { get; set; }

    static Lists()
    {
        admins = new List<Admin>()
        {
            new Admin("Yusif", "Veliyev","yusif573", 15, "yusif.veliyev573@gmail.com", "642531Aa", 2500),
            new Admin("John", "Donen", "john_doe", 30, "john.doe@example.com", "password123", 3000),
            new Admin("Alice", "Smith", "alice_smith", 25, "alice.smith@example.com", "qwerty456", 2800)
        };
        JsonSerializerOptions op = new JsonSerializerOptions();
        op.WriteIndented = true;
        var jsonAdmins = JsonSerializer.Serialize<List<Admin>>(admins, op);
        File.WriteAllText("Admins.json", jsonAdmins);

        employers = new List<Employer>()
        {
            new Employer("Ismayil","Seyidmammadli","Isi777",26,"isi@gmail.com","123321"),
            new Employer("Michael", "Brown", "MBrown123", 40, "yusufov573@gmail.com", "password456"),
            new Employer("Emily", "Johnson", "EmilyJ456", 30, "emily.johnson@example.com", "abc123")
        };
        JsonSerializerOptions op2 = new JsonSerializerOptions();
        op2.WriteIndented = true;
        var jsonEmployers = JsonSerializer.Serialize<List<Employer>>(employers, op2);
        File.WriteAllText("Employers.json", jsonEmployers);


        vacations = new List<Vacation>()
        {
            new Vacation("Isi777","Software developer",4000,"5 days in a week and 8 hours of work","C# knowledge, WPF, SQL, HTML"),
            new Vacation("MBrown123", "Data Analyst",2500, "4 days in a week and 7 hours of work", "Data analysis, SQL, Python, Excel"),
            new Vacation("EmilyJ456", "Web Designer",2000, "6 days in a week and flexible hours", "HTML, CSS, JavaScript, Adobe Photoshop")
        };
        JsonSerializerOptions op3 = new JsonSerializerOptions();
        op3.WriteIndented = true;
        var jsonVacations = JsonSerializer.Serialize<List<Vacation>>(vacations, op3);
        File.WriteAllText("Vacations.json", jsonVacations);


        workers = new List<WorkerClass>()
        {
            new WorkerClass("Cavid","Atamoghlanov","Cavid123",26,"cavid@gmail.com","1234567","994508008000","Baku",null),
            new WorkerClass("Elvin", "Aliyev", "Elvin456", 30, "elvin@gmail.com", "7654321", "994509009000", "Ganja", null),
            new WorkerClass("Aysel", "Mammadova", "Aysel789", 28, "zakiyya.zh@gmail.com", "123456", "994509509000", "Sumqayit", null)
        };
        JsonSerializerOptions op4 = new JsonSerializerOptions();
        op4.WriteIndented = true;
        var jsonWorkers = JsonSerializer.Serialize<List<WorkerClass>>(workers, op4);
        File.WriteAllText("Workers.json", jsonWorkers);

        notifications = new List<NotificationClass>() { };
    }
}
