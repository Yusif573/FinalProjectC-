﻿using FinalProjectVacationSite.DataBase;
using FinalProjectVacationSite.FilesForJob;
using FinalProjectVacationSite.Notification;
using FinalProjectVacationSite.Person;
using FinalProjectVacationSite.Person.User.Worker;
using System;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace FinalProjectVacationSite.Person.User;

public class UserClass : PersonClass
{
    //static public int _staticId { get; set; }
    //public int _id { get; set; }

    public string? Username { get; set; }

    protected string? _email;
    public string? Email
    {
        get { return _email; }
        set
        {
            Regex regEx = new Regex(@"^[\w-]+(\.[\w-]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-zA-Z]{2,})$", RegexOptions.IgnoreCase);
            if (regEx.IsMatch(value))
            {
                _email = value;
            }
            else
            {
                Console.WriteLine("Incorrect information!");
                Console.Write("Enter email:");
                Email = Console.ReadLine();
            }
        }
    }

    protected string? _password;
    public string? Password
    {
        get { return _password; }
        set
        {
            if (value.Length < 6)
            {
                Console.WriteLine("At least must be 6 symbols!");
                Console.Write("Enter password:");
                Password = Console.ReadLine();
            }
            else
            {
                _password = value;
            }
        }
    }
    public UserClass()
        :base()
    {

    }
    public UserClass(string name, string surname, string username, uint age, string email, string password)
        : base(name, surname, age)
    {
        Username = username;
        Email = email;
        Password = password;
    }

    public virtual void Delete(int id, UserClass user)
    {
        Lists.vacations.RemoveAt(id-1);
        Console.WriteLine("Vacation deleted");
        JsonSerializerOptions op3 = new JsonSerializerOptions();
        op3.WriteIndented = true;
        var jsonVacations = JsonSerializer.Serialize<List<Vacation>>(Lists.vacations, op3);
        File.WriteAllText("Vacations.json", jsonVacations);
        return;
    }
    public virtual void sendNotifications(UserClass user)
    {
        NotificationClass newNotification = new NotificationClass();
        Console.Write("Enter notification text:");
        newNotification.Text = Console.ReadLine();
        Console.Write("For:");
        newNotification.ToUserName = Console.ReadLine();
        newNotification.FromUser = user;
        Lists.notifications.Add(newNotification);
    }
    public virtual void showNotifications(UserClass user)
    {
        foreach (NotificationClass notification in Lists.notifications)
        {
            if (user.Username == notification.ToUserName)
            {
                Console.WriteLine(notification.showNotification());
                Console.WriteLine();
            }
        }
    }
    public virtual void showWorkers()
    {
        foreach (WorkerClass worker in Lists.workers)
        {
            Console.WriteLine(worker.Name);
            Console.WriteLine(worker.Surname);
            Console.WriteLine(worker.Age);
            Console.WriteLine(worker.Username);
            Console.WriteLine(worker.City);
            Console.WriteLine(worker.PhoneNumber);
            Console.WriteLine();
        }
    }
    public virtual void showVacations()
    {
        foreach (var vacation in Lists.vacations)
        {
            Console.WriteLine(vacation.ToString());
            Console.WriteLine();
        }
    }

    public override string ToString()
    {
        return base.ToString() + $"\nUsername:{Username}\nEmail:{_email}\nPassword:{_password}";
    }
}
