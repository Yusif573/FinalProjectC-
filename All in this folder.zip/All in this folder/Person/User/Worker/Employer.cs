﻿using FinalProjectVacationSite.DataBase;
using FinalProjectVacationSite.FilesForJob;
using FinalProjectVacationSite.Notification;
using System.Text.Json;

namespace FinalProjectVacationSite.Person.User.Worker;

public class Employer : UserClass, IShow
{

    public Employer()
        :base()
    {
        
    }
    public Employer(string name, string surname,string username, uint age, string email, string password)
        : base(name, surname,username, age, email, password)
    {
    }
    public override void Delete(int id, UserClass user)
    {
        foreach (var vacation in Lists.vacations)
        {
            if (id == vacation._id && user.Username == vacation.UsernameOfEmployer) 
            {
                base.Delete(id, user);
                return;
            }
        }
        Console.WriteLine("You can not delete this vacation!");
    }
    public void createVacation(Employer employer)
    {
        Vacation newVacation = new Vacation();
        newVacation.UsernameOfEmployer = employer.Name;
        Console.Write("Enter name:");
        newVacation.Name = Console.ReadLine();
        Console.Write("Enter salary:");
        newVacation.Salary = Convert.ToUInt32(Console.ReadLine());
        Console.Write("Enter content:");
        newVacation.Content = Console.ReadLine();
        Console.Write("Enter requirements:");
        newVacation.Requirements = Console.ReadLine();
        Lists.vacations.Add(newVacation);
        Console.WriteLine("You created a vacation!");

        File.Delete("Vacations.json");
        JsonSerializerOptions op4 = new JsonSerializerOptions();
        op4.WriteIndented = true;
        var jsonVacations = JsonSerializer.Serialize<List<Vacation>>(Lists.vacations, op4);
        File.WriteAllText("Employers.json", jsonVacations);

    }
    public override void showNotifications(UserClass user)
    {
        base.showNotifications(user);
    }
    public override void sendNotifications(UserClass user)
    {
        base.sendNotifications(user);
    }
    public override void showVacations()
    {
        base.showVacations();
    }
    public override void showWorkers()
    {
        base.showWorkers();
    }
    public override string ToString()
    {
        return base.ToString();
    }


}
