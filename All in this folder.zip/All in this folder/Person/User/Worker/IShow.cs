﻿using FinalProjectVacationSite.FilesForJob;
using FinalProjectVacationSite.Notification;

namespace FinalProjectVacationSite.Person.User.Worker;

public interface IShow
{
    public void showNotifications()
    {

    }
    public void showVacations();
    public void showWorkers();
    public void showEmployers()
    {

    }
}
