﻿using FinalProjectVacationSite.DataBase;
using FinalProjectVacationSite.FilesForJob;
using FinalProjectVacationSite.Notification;
using System.Text.RegularExpressions;

namespace FinalProjectVacationSite.Person.User.Worker;

public class WorkerClass : UserClass, IShow
{
    public CVclass[] CVs { get; set; }
    //public List<NotificationClass> Notifications { get; set; }
    //public List<Vacation> vacations { get; set; }
    string _phoneNumber;
    public string PhoneNumber
    {
        get { return _phoneNumber; }
        set
        {
            Regex regEx = new Regex(@"^(?:0|994)(?:12|51|50|55|70|77)[^\w]{0,2}[2-9][0-9]{2}[^\w]{0,2}[0-9]{2}[^\w]{0,2}[0-9]{2}$", RegexOptions.IgnoreCase);
            if (regEx.IsMatch(value))
            {
                _phoneNumber = value;
            }
            else
            {
                Console.WriteLine("Wrong phone information!");
                Console.Write("Enter number:");
                PhoneNumber = Console.ReadLine();
            }
        }
    }
    public string City { get; set; }

    public WorkerClass()
        :base()
    {
        
    }
    public WorkerClass(string name, string surname, string username, uint age, string email, string password, string phoneNumber, string city, CVclass[] cVs)
        : base(name, surname, username, age, email, password)
    {
        PhoneNumber = phoneNumber;
        City = city;
        CVs = cVs;
    }
    public override void sendNotifications(UserClass user)
    {
        base.sendNotifications(user);
    }
    public override void showNotifications(UserClass user)
    {
        base.showNotifications(user);
    }

    public override void showVacations()
    {
        base.showVacations();
    }

    public override void showWorkers()
    {
        base.showWorkers();
    }
    public override string ToString()
    {
        foreach (var cv in CVs)
        {
            cv.ToString();
            Console.WriteLine();
        }
        return base.ToString()+$"\nPhone number:{PhoneNumber}\nCity:{City}";

    }


}
