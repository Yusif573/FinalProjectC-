﻿using FinalProjectVacationSite.DataBase;
using FinalProjectVacationSite.FilesForJob;
using System.Text.Json;

namespace FinalProjectVacationSite.Person.User.Worker;

public class Admin : UserClass, IShow
{
    //public List<Employer> Employers { get; set; }
    //public List<WorkerClass> Workers { get; set; }
    //public List<Vacation> Vacations { get; set; }
    public uint Salary { get; set; }

    public Admin(string name,string surname,string username,uint age,string email,string password,uint salary)
        :base(name,surname,username,age,email,password)
    {
        Salary = salary;
    }

    public override void Delete(int id, UserClass user)
    {
        foreach (var vacation in Lists.vacations)
        {
            if (id == vacation._id)
            {
                base.Delete(id, user);
                return;
            }
        }
        Console.WriteLine("There is no vacation with this id!");
    }
    public void EnableVacation(int id)
    {
        foreach(var vacation in Lists.vacations)
        {
            if (vacation._id == id)
            {
                vacation.Enabled = true;
                Console.WriteLine("Vacation enabled");
                File.Delete("Vacations.json");
                JsonSerializerOptions op3 = new JsonSerializerOptions();
                op3.WriteIndented = true;
                var jsonVacations = JsonSerializer.Serialize<List<Vacation>>(Lists.vacations, op3);
                File.WriteAllText("Vacations.json", jsonVacations);
                return;
            }

        }
        Console.WriteLine("There is no vacation with this id!!!");
    }


    public void showEmployers()
    {
        foreach(Employer employer in Lists.employers)
        {
            Console.WriteLine(employer.ToString());
            Console.WriteLine();
        }
    }
    public void showVacations()
    {
        foreach (Vacation vacation in Lists.vacations)
        {
            Console.WriteLine(vacation.ToString());
            Console.WriteLine();
        }
    }
    public void showWorkers()
    {
        foreach (WorkerClass worker in Lists.workers)
        {
            Console.WriteLine(worker.ToString());
            Console.WriteLine();

        }
    }

    public override string ToString()
    {
        return base.ToString()+$"\nSalary:{Salary}";
    }
}
