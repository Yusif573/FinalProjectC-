﻿using FinalProjectVacationSite.FilesForJob;
using FinalProjectVacationSite.Notification;
using FinalProjectVacationSite.Person.User;
using System.Net.Mail;
using System.Net;
using FinalProjectVacationSite.Person.User.Worker;
using System.Text.Json;
using FinalProjectVacationSite.Person;
using FinalProjectVacationSite.DataBase;
using System;


public class Program
{
    static void selectFunction(ref int select, int maxSelect, int minSelect, ref bool enterSelected)
    {
        while (true)
        {
            ConsoleKeyInfo consoleKeyInfo = Console.ReadKey(true);
            if (consoleKeyInfo.Key == ConsoleKey.UpArrow)
            {
                if (select == minSelect) { select = maxSelect; }
                else { select--; }
            }
            else if (consoleKeyInfo.Key == ConsoleKey.DownArrow)
            {
                if (select == maxSelect) { select = minSelect; }
                else { select++; }
            }
            else if (consoleKeyInfo.Key == ConsoleKey.Enter)
            {

                enterSelected = false;

            }
            return;
        }

    }
    static void showMenu(string[] menu, int select)
    {
        for (int i = 0; i < menu.Length; i++)
        {
            if (select == i + 1)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(menu[i]);
                Console.ForegroundColor = ConsoleColor.White;
                continue;
            }
            Console.WriteLine(menu[i]);
        }
    }

    static void smtpFunction(string checkEmail, ref bool userFound,int randomNumber)
    {
        userFound = true;

        string? senderEmail = "yusif.veliyev573@gmail.com";
        string senderPassword = "lvrl hqhv sqve ncbm";

        string? recipientEmail = checkEmail;

        string smtpServer = "smtp.gmail.com";
        int port = 587;
        SmtpClient client = new SmtpClient(smtpServer, port);
        client.EnableSsl = true;

        client.Credentials = new NetworkCredential(senderEmail, senderPassword);

        MailMessage message = new MailMessage(senderEmail, recipientEmail);
        message.Subject = "Verifying from boss az";
        message.Body = $"{randomNumber}";
        Console.Clear();
        try
        {
            client.Send(message);
            Console.WriteLine("Email sent successfully!");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed to send email: {ex.Message}");
            Console.Clear();
            workerSignIn();
        }
        finally
        {
            message.Dispose();
            client.Dispose();
        }
    }
    static void workerSignUp()
    {
        Console.Clear();
        Console.WriteLine("Press ESCAPE to return or ANY key to continue");
        ConsoleKeyInfo escapeKeyInfo = Console.ReadKey(true);
        if (escapeKeyInfo.Key == ConsoleKey.Escape) { workerMenuSelect(); }
        else
        {
            WorkerClass newWorker = new WorkerClass();
            Console.Write("Enter name:");
            newWorker.Name = Console.ReadLine();
            Console.Write("Enter surname:");
            newWorker.Surname = Console.ReadLine();
            Console.Write("Enter age:");
            newWorker.Age = Convert.ToUInt32(Console.ReadLine());
            Console.Write("Ente email:");
            newWorker.Email = Console.ReadLine();
            Console.Write("Enter password:");
            newWorker.Password = Console.ReadLine();
            foreach (WorkerClass worker in Lists.workers)
            {
                if (newWorker.Email.ToLower() == worker.Email.ToLower())
                {
                    Console.WriteLine("Admin with this email already exist!");
                    Thread.Sleep(2000);
                    workerSignUp();
                }
            }
            while (true)
            {
                Console.Write("Enter username:");
                newWorker.Username = Console.ReadLine();
                foreach (Employer employer in Lists.employers)
                {
                    if (newWorker.Username == employer.Username)
                    {
                        Console.WriteLine("This username is used by other admin!");
                        Console.Write("Enter username:");
                        newWorker.Username = Console.ReadLine();
                    }
                }
                break;
            }
            Console.Write("Enter city:");
            newWorker.City = Console.ReadLine();
            Console.Write("Enter phone number:");
            newWorker.PhoneNumber = Console.ReadLine();

            Lists.workers.Add(newWorker);
            
            Console.Clear();
            Console.WriteLine("You have successfully signed up)");

            File.Delete("Workers.json");
            JsonSerializerOptions op4 = new JsonSerializerOptions();
            op4.WriteIndented = true;
            var jsonEmployers = JsonSerializer.Serialize<List<WorkerClass>>(Lists.workers, op4);
            File.WriteAllText("Workers.json", jsonEmployers);

            Thread.Sleep(2000);
            Console.Clear();
            workerMenuSelect();

        }
    }
    static void workerSignIn()
    {
        Console.Clear();
        Console.Write("Enter email:");
        string? checkEmail = Console.ReadLine();
        Console.Write("Enter password:");
        string? checkPassword = Console.ReadLine();
        int select = 1;
        bool workerMenuEnter = true;
        bool workerFound = false;
        foreach (WorkerClass worker  in Lists.workers)
        {
            if (checkEmail == worker.Email && checkPassword == worker.Password)
            {
                Random random = new Random();
                int randomNumber = random.Next(100,1000);
                smtpFunction(checkEmail, ref workerFound,randomNumber);


                Console.Write("Enter verifying code:");
                int verCode = Convert.ToInt32(Console.ReadLine());
                if (randomNumber == verCode)
                {
                    Console.Clear();
                    Console.WriteLine("You have successfully entered)");
                    Thread.Sleep(2000);
                    string[] menuAfterLogIn = { "1 - All vacations", "2 - All workers", "3 - Send notification", "4 - Notifications", "5 - Exit" };
                    while (true)
                    {
                        while (workerMenuEnter)
                        {
                            Console.Clear();
                            showMenu(menuAfterLogIn, select);
                            selectFunction(ref select, menuAfterLogIn.Length, 1, ref workerMenuEnter);
                            Console.Clear();
                        }
                        if (select == 1)
                        {
                            worker.showVacations();

                            Console.WriteLine("Press ANY key to return");
                            ConsoleKeyInfo consoleKeyInfo = Console.ReadKey(true);
                        }
                        else if (select == 2)
                        {
                            worker.showWorkers();
                            Console.WriteLine("Press ANY key to return");
                            ConsoleKeyInfo consoleKeyInfo = Console.ReadKey(true);
                        }
                        else if (select == 3)
                        {
                            worker.sendNotifications(worker);
                            Console.WriteLine("Press ANY key to return");
                            ConsoleKeyInfo consoleKeyInfo = Console.ReadKey(true);
                        }
                        else if (select == 4)
                        {
                            worker.showNotifications(worker);
                            Console.WriteLine("Press ANY key to return");
                            ConsoleKeyInfo consoleKeyInfo = Console.ReadKey(true);
                        }
                        else
                        {
                            workerMenuSelect();
                            break;
                        }
                        workerMenuEnter = true;
                    }
                    break;
                }
                else
                {
                    Console.WriteLine("Incorrect verifying code!");
                    Thread.Sleep(2000);
                    Console.Clear();
                    Console.WriteLine("Press ESCAPE to return or ANY key to continue");
                    ConsoleKeyInfo escapeKeyInfo = Console.ReadKey(true);
                    if (escapeKeyInfo.Key == ConsoleKey.Escape) { workerMenuSelect(); }
                    else
                    {
                        workerSignIn();
                    }
                }

            }
        }
        if (!workerFound)
        {
            Console.WriteLine("Incorrect information!");
            Thread.Sleep(2000);
            Console.Clear();
            Console.WriteLine("Press ESCAPE to return or ANY key to continue");
            ConsoleKeyInfo escapeKeyInfo = Console.ReadKey(true);
            if (escapeKeyInfo.Key == ConsoleKey.Escape) { workerMenuSelect(); }
            else
            {
                workerSignIn();
            }
        }
    }
    static void workerMenuSelect()
    {
        string[] userMenu = { "1 - Sign in", "2 - Sign up", "3 - Exit" };
        int select = 1;
        bool userMenuEnterSelected = true;
        while (userMenuEnterSelected)
        {

            showMenu(userMenu, select);
            selectFunction(ref select, userMenu.Length, 1, ref userMenuEnterSelected);
            Console.Clear();
        }
        if (select == 1)
        {
            workerSignIn();
        }
        else if (select == 2)
        {
            workerSignUp();
        }
        else
        {
            firstMenuSelect();
        }
    }
    static void employerSignUp()
    {
        Console.Clear();
        Console.WriteLine("Press ESCAPE to return or ANY key to continue");
        ConsoleKeyInfo escapeKeyInfo = Console.ReadKey(true);
        if (escapeKeyInfo.Key == ConsoleKey.Escape) { employerMenuSelect(); }
        else
        {
            Employer newEmployer = new Employer();
            Console.Write("Enter name:");
            newEmployer.Name = Console.ReadLine();
            Console.Write("Enter surname:");
            newEmployer.Surname = Console.ReadLine();
            Console.Write("Enter age:");
            newEmployer.Age = Convert.ToUInt32(Console.ReadLine());
            Console.Write("Ente email:");
            newEmployer.Email = Console.ReadLine();
            Console.Write("Enter password:");
            newEmployer.Password = Console.ReadLine();
            foreach (Employer employer in Lists.employers)
            {
                if (newEmployer.Email.ToLower() == employer.Email.ToLower())
                {
                    Console.WriteLine("Admin with this email already exist!");
                    Thread.Sleep(2000);
                    employerSignUp();
                }
            }
            while (true)
            {
                Console.Write("Enter username:");
                newEmployer.Username = Console.ReadLine();
                foreach (Employer employer in Lists.employers)
                {
                    if (newEmployer.Username == employer.Username)
                    {
                        Console.WriteLine("This username is used by other admin!");
                        Console.Write("Enter username:");
                        newEmployer.Username = Console.ReadLine();
                    }
                }
                break;
            }
            Lists.employers.Add(newEmployer);
            Console.Clear();
            Console.WriteLine("You have successfully signed up)");

            File.Delete("Employers.json");
            JsonSerializerOptions op4 = new JsonSerializerOptions();
            op4.WriteIndented = true;
            var jsonEmployers = JsonSerializer.Serialize<List<Employer>>(Lists.employers, op4);
            File.WriteAllText("Employers.json", jsonEmployers);

            Thread.Sleep(2000);
            Console.Clear();
            employerMenuSelect();

        }
    }
    static void employerSignIn()
    {
        Console.Clear();
        Console.Write("Enter email:");
        string? checkEmail = Console.ReadLine();
        Console.Write("Enter password:");
        string? checkPassword = Console.ReadLine();
        int select = 1;
        bool employerMenuEnter = true;
        bool employerFound = false;
        foreach (Employer employer in Lists.employers)
        {
            if (checkEmail == employer.Email && checkPassword == employer.Password)
            {
                
                Random random = new Random();
                int randomNumber = random.Next(100, 1000);
                smtpFunction(checkEmail, ref employerFound, randomNumber);

                Console.Write("Enter verifying code:");
                int verCode = Convert.ToInt32(Console.ReadLine());
                if (randomNumber == verCode)
                {
                    Console.Clear();
                    Console.WriteLine("You have successfully entered)");
                    Thread.Sleep(2000);
                    string[] menuAfterLogIn = { "1 - All vacations", "2 - All workers", "3 - Create vacation", "4 - Delete vacation", "5 - Send notification to worker","6 - Notifications","7 - Exit" };
                    while (true)
                    {
                        while (employerMenuEnter)
                        {
                            Console.Clear();
                            showMenu(menuAfterLogIn, select);
                            selectFunction(ref select, menuAfterLogIn.Length, 1, ref employerMenuEnter);
                            Console.Clear();
                        }
                        if (select == 1)
                        {
                            employer.showVacations();

                            Console.WriteLine("Press ANY key to return");
                            ConsoleKeyInfo consoleKeyInfo = Console.ReadKey(true);
                        }
                        else if (select == 2)
                        {
                            employer.showWorkers();
                            Console.WriteLine("Press ANY key to return");
                            ConsoleKeyInfo consoleKeyInfo = Console.ReadKey(true);
                        }
                        else if (select == 3)
                        {
                            employer.createVacation(employer);
                        }   
                        else if (select == 4)
                        {
                            Console.Write("Enter vacation id:");
                            int id = Convert.ToInt32(Console.ReadLine());
                            employer.Delete(id, employer);
                            Console.WriteLine("Press ANY key to return");
                            ConsoleKeyInfo consoleKeyInfo = Console.ReadKey(true);
                        }
                        else if (select == 5)
                        {
                            employer.sendNotifications(employer);
                            Console.WriteLine("Press ANY key to return");
                            ConsoleKeyInfo consoleKeyInfo = Console.ReadKey(true);
                        }
                        else if (select == 6)
                        {
                            employer.showNotifications(employer);
                            Console.WriteLine("Press ANY key to return");
                            ConsoleKeyInfo consoleKeyInfo = Console.ReadKey(true);
                        }
                        else
                        {
                            employerMenuSelect();
                            break;
                        }
                        employerMenuEnter = true;
                    }
                    break;
                }
                else
                {
                    Console.WriteLine("Incorrect verifying code!");
                    Thread.Sleep(2000);
                    Console.Clear();
                    Console.WriteLine("Press ESCAPE to return or ANY key to continue");
                    ConsoleKeyInfo escapeKeyInfo = Console.ReadKey(true);
                    if (escapeKeyInfo.Key == ConsoleKey.Escape) { employerMenuSelect(); }
                    else
                    {
                        employerSignIn();
                    }
                }

            }
        }
        if (!employerFound)
        {
            Console.WriteLine("Incorrect information!");
            Thread.Sleep(2000);
            Console.Clear();
            Console.WriteLine("Press ESCAPE to return or ANY key to continue");
            ConsoleKeyInfo escapeKeyInfo = Console.ReadKey(true);
            if (escapeKeyInfo.Key == ConsoleKey.Escape) { employerMenuSelect(); }
            else
            {
                employerSignIn();
            }
        }
    }
    static void employerMenuSelect()
    {
        string[] userMenu = { "1 - Sign in", "2 - Sign up", "3 - Exit" };
        int select = 1;
        bool userMenuEnterSelected = true;
        while (userMenuEnterSelected)
        {

            showMenu(userMenu, select);
            selectFunction(ref select, userMenu.Length, 1, ref userMenuEnterSelected);
            Console.Clear();
        }
        if (select == 1)
        {
            employerSignIn();
        }
        else if (select == 2)
        {
            employerSignUp();
        }
        else
        {
            firstMenuSelect();
        }
    }
    static void adminSignIn()
    {
        Console.Clear();
        Console.Write("Enter email:");
        string? checkEmail = Console.ReadLine();
        Console.Write("Enter password:");
        string? checkPassword = Console.ReadLine();
        int select = 1;
        bool adminMenuEnter = true;
        bool adminFound = false;
        foreach (Admin admin in Lists.admins) {
            if (checkEmail == admin.Email && checkPassword == admin.Password)
            {
                
                Random random = new Random(); 
                int randomNumber = random.Next(100,1000);
                smtpFunction(checkEmail, ref adminFound, randomNumber);
                
                Console.Write("Enter verifying code:");
                int verCode = Convert.ToInt32(Console.ReadLine());
                if (randomNumber == verCode)
                {
                    Console.Clear();
                    Console.WriteLine("You have successfully entered)");
                    Thread.Sleep(2000);
                    string[] menuAfterLogIn = { "1 - All vacations", "2 - All employers", "3 - All workers", "4 - Enable vacation","5 - Delete vacation","6 - Exit" };
                    while (true)
                    {
                        while (adminMenuEnter)
                        {
                            Console.Clear();
                            showMenu(menuAfterLogIn, select);
                            selectFunction(ref select, menuAfterLogIn.Length, 1, ref adminMenuEnter);
                            Console.Clear();
                        }
                        if (select == 1)
                        {
                            admin.showVacations();
                            
                            Console.WriteLine("Press ANY key to return");
                            ConsoleKeyInfo consoleKeyInfo = Console.ReadKey(true);
                        }
                        else if (select == 2)
                        {
                            admin.showEmployers();
                            Console.WriteLine("Press ANY key to return");
                            ConsoleKeyInfo consoleKeyInfo = Console.ReadKey(true);
                        }
                        else if (select == 3)
                        {
                            admin.showWorkers();
                            Console.WriteLine("Press ANY key to return");
                            ConsoleKeyInfo consoleKeyInfo = Console.ReadKey(true);
                        }
                        else if (select == 4)
                        {
                            Console.Write("Enter vacation id:");
                            int id = Convert.ToInt32(Console.ReadLine());
                            admin.EnableVacation(id);
                            Console.WriteLine("Press ANY key to return");
                            ConsoleKeyInfo consoleKeyInfo = Console.ReadKey(true);
                        }
                        else if (select == 5)
                        {
                            Console.Write("Enter vacation id:");
                            int id = Convert.ToInt32(Console.ReadLine());
                            admin.Delete(id, admin);
                            Console.WriteLine("Press ANY key to return");
                            ConsoleKeyInfo consoleKeyInfo = Console.ReadKey(true);
                        }
                        else
                        {
                            adminMenuSelect();
                            break;
                        }
                        adminMenuEnter = true;
                    }
                    break;
                }
                else
                {
                    Console.WriteLine("Incorrect verifying code!");
                    Thread.Sleep(2000);
                    Console.Clear();
                    Console.WriteLine("Press ESCAPE to return or ANY key to continue");
                    ConsoleKeyInfo escapeKeyInfo = Console.ReadKey(true);
                    if (escapeKeyInfo.Key == ConsoleKey.Escape) { adminMenuSelect(); }
                    else
                    {
                        adminSignIn();
                    }
                }

            }
        }
        if (!adminFound)
        {
            Console.WriteLine("Incorrect information!");
            Thread.Sleep(2000);
            Console.Clear();
            Console.WriteLine("Press ESCAPE to return or ANY key to continue");
            ConsoleKeyInfo escapeKeyInfo = Console.ReadKey(true);
            if (escapeKeyInfo.Key == ConsoleKey.Escape) { adminMenuSelect(); }
            else
            {
                adminSignIn();
            }
        }

    }
    static void adminMenuSelect()
    {
        string[] adminMenu = { "1 - Sign in", "2 - Exit" };
        int select = 1;
        bool adminMenuEnterSelected = true;
        while (adminMenuEnterSelected)
        {
            showMenu(adminMenu, select);
            selectFunction(ref select, adminMenu.Length, 1, ref adminMenuEnterSelected);
            Console.Clear();
        }
        if (select == 1)
        {
            adminSignIn();
        }
        else { firstMenuSelect(); }
    }
    static void firstMenuSelect()
    {
        string[] menu = { "1 - Admin", "2 - Employer", "3 - Worker","4 - Exit" };
        int select = 1;
        bool firstMenuEnterSelected = true;
        while (firstMenuEnterSelected)
        {
            showMenu(menu, select);
            selectFunction(ref select, menu.Length, 1, ref firstMenuEnterSelected);
            Console.Clear();
        }
        if (select == 1)
        {
            adminMenuSelect();
        }
        else if (select == 2)
        {
            employerMenuSelect();
        }
        else if (select == 3)
        {
            workerMenuSelect();
        }
        else { return; }

    }
    private static void Main(string[] args)
    { 
        Vacation._staticId = 1;
        NotificationClass._notificationStaticId = 1;


        firstMenuSelect();
    }
}