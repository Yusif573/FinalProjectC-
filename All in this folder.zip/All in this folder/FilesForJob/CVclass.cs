﻿namespace FinalProjectVacationSite.FilesForJob;

public class CVclass
{
    public string Ixtisas { get; set; }
    public string OxuduguMekteb { get; set; }
    public int UniyeQebulBali { get; set; }
    public string[] Bacariqlar { get; set; }
    public string[] IshlediyiYerler { get; set; }
    public int Staj { get; set; }
    public string[] BildiyiDillerVeLevelleri { get; set; }
    public bool FerqlenmeDiplomu { get; set; }
    public CVclass(string ixtisas, string oxuduguMekteb, int uniyeQebulBali, string[] bacariqlar, string[] ishlediyiYerler, int staj, string[] bildiyiDillerVeLevelleri, bool ferqlenmeDiplomu)
    {
        Ixtisas = ixtisas;
        OxuduguMekteb = oxuduguMekteb;
        UniyeQebulBali = uniyeQebulBali;
        Bacariqlar = bacariqlar;
        IshlediyiYerler = ishlediyiYerler;
        Staj = staj;
        BildiyiDillerVeLevelleri = bildiyiDillerVeLevelleri;
        FerqlenmeDiplomu = ferqlenmeDiplomu;
    }

    public override string ToString()
    {
        return $"Ixtisas:{Ixtisas}\nOxudugu mekteb:{OxuduguMekteb}\nUniversitete qebul bali:{UniyeQebulBali}" +
            $"\nBacariqlar:{string.Join(",", Bacariqlar)}\nIslediyi yerler:{string.Join(",", IshlediyiYerler)}\nIs tecrubesi:{Staj}\n" +
            $"Diller:{string.Join(",", BildiyiDillerVeLevelleri)}\nFerqlendirme diplomu:{FerqlenmeDiplomu}";
    }
}
