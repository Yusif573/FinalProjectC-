﻿namespace FinalProjectVacationSite.FilesForJob;

public class Vacation
{
    public static int _staticId {  get; set; }
    public int _id { get; set; }

    public string UsernameOfEmployer { get; set; }
    public string Name { get; set; }
    public uint Salary { get; set; }
    public string Content { get; set; }
    public string Requirements { get; set; }
    public bool Enabled { get; set; }
    public DateTime dateTime { get; set; }
    public Vacation()
    {
        _id = _staticId++;
        Enabled = false;
        dateTime = DateTime.Now;
    }
    public Vacation(string usernameOfEmployer,string name,uint salary, string content, string requirements)
        :this()
    {
        UsernameOfEmployer = usernameOfEmployer;
        Name = name;
        Salary = salary;
        Content = content;
        Requirements = requirements;
    }

    public override string ToString()
    {
        return $"Id:{_id}\nEmployer:{UsernameOfEmployer}\nName:{Name}\nSalary:{Salary}\nContent:{Content}\nRequirements{Requirements}\nEnabled:{Enabled}\nWill be enable untill:{dateTime.Day}.{dateTime.Month+1}.{dateTime.Year}";
    }
}
